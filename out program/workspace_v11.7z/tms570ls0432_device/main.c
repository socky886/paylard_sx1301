#include "TC_CUBESAT_Connections.h"
#include "gio.h"
#include "can.h"
#include "spi.h"
#include "het.h"
#include "sci.h"

#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include "sx1278_driver\SX1278.h"

#define UART scilinREG

//---------------weijunfeng added 20220611--------------------
SX1278_hw_t SX1278_hw_tx;
SX1278_t SX1278_tx;
int master=1;
int ret;
char buffer[512];
int message;
int message_length;

spiDAT1_t dataconfig1_tx={
    .CS_HOLD=FALSE,
    .WDEL=TRUE,
    .DFSEL = SPI_FMT_1,
    .CSNR = 0,

};

SX1278_hw_t SX1278_hw_rx;
SX1278_t SX1278_rx;
spiDAT1_t dataconfig1_rx={
    .CS_HOLD=FALSE,
    .WDEL=TRUE,
    .DFSEL = SPI_FMT_1,
    .CSNR = 0,

};


// redirect fputc for printf
int32_t fputc(int32_t ch,FILE*f)
{
	uint8 data=(uint8)ch;
    sciSendByte(UART, data); /* send out text   */
    return ch;
}
// redirect fputc for printf
int fputs(const char *_ptr, register FILE *_fp)
{
  unsigned int i, len;

  len = strlen(_ptr);
  sciSend(UART,len,(uint8_t *)_ptr);

  return len;
}


// init the SX1278 for TX
void sx1278_tx_init(void)
{
    // initialize LoRa module
    SX1278_hw_tx.dio0.port = (void *)general_port;
    SX1278_hw_tx.dio0.pin = tx_init_pin;
    SX1278_hw_tx.nss.port = (void *)tx_cs_port;
    SX1278_hw_tx.nss.pin = tx_cs_pin;
    SX1278_hw_tx.reset.port = (void *)general_port;
    SX1278_hw_tx.reset.pin = tx_reset_pin;
    SX1278_hw_tx.spi = (void *)tx_port;
    SX1278_hw_tx.dataconfig1_p = &dataconfig1_tx;

    SX1278_tx.hw = &SX1278_hw_tx;

    SX1278_hw_Reset(SX1278_tx.hw);
    sx1278_spi_test(&SX1278_tx);

}

// init the SX1278 for RX
void sx1278_rx_init(void)
{
    // initialize LoRa module
    SX1278_hw_rx.dio0.port = (void *)general_port;
    SX1278_hw_rx.dio0.pin = rx_init_pin;
    SX1278_hw_rx.nss.port = (void *)rx_cs_port;
    SX1278_hw_rx.nss.pin = rx_cs_pin;
    SX1278_hw_rx.reset.port = (void *)general_port;
    SX1278_hw_rx.reset.pin = rx_reset_pin;
    SX1278_hw_rx.spi = (void *)rx_port;
    SX1278_hw_rx.dataconfig1_p = &dataconfig1_rx;

    SX1278_rx.hw = &SX1278_hw_rx;

    SX1278_hw_Reset(SX1278_rx.hw);
    sx1278_spi_test(&SX1278_rx);

}
void main(void)
{
    gioInit();
    spiInit();
    canInit();
    hetInit();
    sciInit();
    bb_poweron();
    pa_poweroff();

    uart_receiver_mode();
    master=0;
    sx1278_tx_init();
    sx1278_rx_init();

	// sx1278_spi_test(&SX1278_tx);


    printf("Configuring LoRa module\r\n");
    // SX1278_init(&SX1278_tx, 434000000, SX1278_POWER_17DBM, SX1278_LORA_SF_7,
    // SX1278_LORA_BW_125KHZ, SX1278_LORA_CR_4_5, SX1278_LORA_CRC_EN, 10);
    SX1278_init(&SX1278_tx, 490000000, SX1278_POWER_17DBM, SX1278_LORA_SF_7,
                SX1278_LORA_BW_125KHZ, SX1278_LORA_CR_4_5, SX1278_LORA_CRC_EN, 10);

    // SX1278_init(&SX1278_rx, 490000000, SX1278_POWER_17DBM, SX1278_LORA_SF_7,
    //             SX1278_LORA_BW_125KHZ, SX1278_LORA_CR_4_5, SX1278_LORA_CRC_EN, 10);
    
    printf("Done configuring LoRaModule\r\n");
    // if (master == 1)
    // {
    //     ret = SX1278_LoRaEntryTx(&SX1278_tx, 16, 2000);
    //     printf("enter tx mode\n");
    // }
    // else
    // {
    //     ret = SX1278_LoRaEntryRx(&SX1278_rx, 16, 2000);
    //     printf("enter rx mode\n");
    // }


    while (1)
    {
        // send message
        message_length = sprintf(buffer, "Hello %d", message);
        ret = SX1278_LoRaEntryTx(&SX1278_tx, message_length, 2000);
        if(ret)
            printf("enter tx mode successfully\n");
        else
            printf("enter tx mode failure\n");
        printf("tms570ls0432_sx1278 send packet paylaod is:\"");
        printf(buffer);
        printf("\"\n");

        ret = SX1278_LoRaTxPacket(&SX1278_tx, (uint8_t*) buffer,message_length, 2000);
        if(ret)
            printf("send lora packet successfully\n");
		message += 1;

        delay_ms(200);
        //receive message
        // ret = SX1278_LoRaRxPacket(&SX1278_rx);
        // printf("Received: %d\r\n", ret);
        // if (ret > 0)
        // {
        //     SX1278_read(&SX1278_rx, (uint8_t *)buffer, ret);
        //     printf("Content (%d): %s\r\n", ret, buffer);
        //     for (int i = 0; i < ret; i++)
        //     {
        //         printf("%02x ", buffer[i]);
        //     }
        //     printf("\n");

        //     //enter rx again
        //     ret = SX1278_LoRaEntryRx(&SX1278_rx, 16, 2000);
        //     if (ret)
        //         printf("enter lora rx mode successfully\n");
        //     else
        //         printf("enter lora rx mode failure\n");
        // }

        //     printf("this is my sx1278 application\n");
        //     delay_ms(200);
        //     if (master == 1)
        //     {
        // 		printf("Master ...\r\n");
        // 		delay_ms(1000);
        // 		printf("Sending package...\r\n");

        // 		message_length = sprintf(buffer, "Hello %d", message);
        // 		ret = SX1278_LoRaEntryTx(&SX1278_tx, message_length, 2000);
        // 		printf("Entry: %d\r\n", ret);

        // 		printf("Sending %s\r\n", buffer);
        // 		ret = SX1278_LoRaTxPacket(&SX1278_tx, (uint8_t*) buffer,
        // 				message_length, 2000);
        // 		message += 1;

        // 		printf("Transmission: %d\r\n", ret);
        // 		printf("Package sent...\r\n");

        // 	} else {
        // 		// printf("Slave ...\r\n");
        // 		// HAL_Delay(800);
        //   // HAL_Delay(5);
        // 		// printf("Receiving package...\r\n");

        // 		ret = SX1278_LoRaRxPacket(&SX1278_rx);
        // 		// printf("Received: %d\r\n", ret);
        // 		if (ret > 0) {
        // 			SX1278_read(&SX1278_rx, (uint8_t*) buffer, ret);
        // 			printf("Content (%d): %s\r\n", ret, buffer);
        //     for (int i = 0; i < ret; i++)
        //     {
        //        printf("%02x ",buffer[i]);
        //     }
        //     printf("\n");

        // 		}
        // 		// printf("Package received ...\r\n");

        // 	}
    }
}

