/**
 * Author Wojciech Domski <Wojciech.Domski@gmail.com>
 * www: www.Domski.pl
 *
 * Hardware layer for SX1278 LoRa module
 */

#include "SX1278_hw.h"
#include <string.h>

#include "gio.h"
#include "TC_CUBESAT_Connections.h"
// #include "spi.h"
#define __weak 
__weak void SX1278_hw_init(SX1278_hw_t *hw) {
	SX1278_hw_SetNSS(hw, 1);
	gioSetBit(hw->reset.port, hw->reset.pin, 1);
}

__weak void SX1278_hw_SetNSS(SX1278_hw_t *hw, int value) {
	gioSetBit(hw->nss.port, hw->nss.pin,
			(value == 1) ? 1 : 0);
}

__weak void SX1278_hw_Reset(SX1278_hw_t *hw) {
	SX1278_hw_SetNSS(hw, 1);
	gioSetBit(hw->reset.port, hw->reset.pin, 1);

	SX1278_hw_DelayMs(1);

	gioSetBit(hw->reset.port, hw->reset.pin, 1);

	SX1278_hw_DelayMs(100);
}

__weak void SX1278_hw_SPICommand(SX1278_hw_t *hw, uint8_t cmd) {
	SX1278_hw_SetNSS(hw, 0);
	uint16_t cmd1=cmd;

	spiTransmitData(hw->spi, hw->dataconfig1_p, 1, &cmd1);
}

__weak uint8_t SX1278_hw_SPIReadByte(SX1278_hw_t *hw) {
	uint16_t txByte = 0x00;
	uint16_t rxByte = 0x00;

	SX1278_hw_SetNSS(hw, 0);
	spiTransmitAndReceiveData(hw->spi, hw->dataconfig1_p,1,&txByte,&rxByte);
	return (rxByte&0xff);
}

__weak void SX1278_hw_DelayMs(uint32_t msec) {
	delay_ms(msec);
}

__weak int SX1278_hw_GetDIO0(SX1278_hw_t *hw) {
	return (gioGetBit(hw->dio0.port, hw->dio0.pin) == 1);
}




uint8_t SX1278_hw_SPIRead(SX1278_hw_t *hw, uint8_t addr)
{
	 
    uint16 spi_data;
    uint16 data;

    hw->dataconfig1_p->DFSEL = SPI_FMT_0;
  
    spi_data = (addr << 8);
    SX1278_hw_SetNSS(hw, 0);
    spiTransmitAndReceiveData(hw->spi, hw->dataconfig1_p, 1, &spi_data, &data);
    SX1278_hw_SetNSS(hw, 1);
    return (data & 0xFF);

	// return tx_bSpiRead(addr);

}
void SX1278_hw_SPIWrite(SX1278_hw_t *hw, uint8_t addr, uint8_t cmd)
{

	uint16 spi_data;
	hw->dataconfig1_p->DFSEL = SPI_FMT_0;

	spi_data = ((addr << 8) | 0x8000) | cmd;
	SX1278_hw_SetNSS(hw, 0);
	spiTransmitData(hw->spi, hw->dataconfig1_p, 1, &spi_data);
	SX1278_hw_SetNSS(hw, 1);

	// tx_vSpiWrite(addr,cmd);
}
void SX1278_hw_SPIBurstRead(SX1278_hw_t *hw, uint8_t addr, uint8_t *rxBuf,uint8_t length)
{
	
	uint16 reg_data;
	uint16 rx_data[255];
	uint8 cnt;
	hw->dataconfig1_p->DFSEL = SPI_FMT_1;

	reg_data = addr;

	SX1278_hw_SetNSS(hw, 0);
	spiTransmitData(hw->spi, hw->dataconfig1_p, 1, &reg_data);
	spiReceiveData(hw->spi, hw->dataconfig1_p, length, &rx_data[0]);
	SX1278_hw_SetNSS(hw, 1);
	for (cnt = 0; cnt < length; cnt++)
	{
		*rxBuf = rx_data[cnt];
		rxBuf++;
	}

	// tx_ReadBuffer(addr,length,rxBuf);
}
void SX1278_hw_SPIBurstWrite(SX1278_hw_t *hw, uint8_t addr, uint8_t *txBuf,uint8_t length)
{
	
	uint16 reg_data;
	uint16 instruction_data[255];
	uint8 cnt;
	hw->dataconfig1_p->DFSEL = SPI_FMT_1;


	reg_data = addr | 0x80;
	for (cnt = 0; cnt < length; cnt++)
	{
		instruction_data[cnt] = *txBuf;
		txBuf++;
	}

	SX1278_hw_SetNSS(hw, 0);

	spiTransmitData(hw->spi, hw->dataconfig1_p, 1, &reg_data);
	spiTransmitData(hw->spi, hw->dataconfig1_p, length, &instruction_data[0]);

	SX1278_hw_SetNSS(hw, 1);

	// tx_WriteBuffer(addr,length,txBuf);
}

