#include "sx1301_app.h"

#include "loragw_hal.h"
#include "loragw_reg.h"
#include "loragw_aux.h"


/* -------------------------------------------------------------------------- */
/* --- PRIVATE MACROS ------------------------------------------------------- */
#define ARRAY_SIZE(a) (sizeof(a) / sizeof((a)[0]))

/* -------------------------------------------------------------------------- */
/* --- PRIVATE CONSTANTS ---------------------------------------------------- */
#define BURST_TEST_SIZE 250 /* >> LGW_BURST_CHUNK */
#define TIMING_REPEAT   1    /* repeat transactions multiple times for timing characterisation */
#define BURST_TEST_LENGTH    256



// #if 0
// #include "main.h"
// extern SPI_HandleTypeDef hspi1;
// BOB_Status_t BOB_HOSTSPI_WriteRead(uint8_t *txData, uint8_t *rxData, uint16_t len, uint16_t Timeout)
// {
//     BOB_Status_t ret = BOB_OK;
//     ret = HAL_SPI_TransmitReceive(&hspi1, txData, rxData, len, Timeout);

//     return ret;
// }

// void host_spi_select(void)
// {
//     HAL_GPIO_WritePin(NSS_GPIO_Port,NSS_Pin,0);
// }
// void host_spi_release(void)
// {
//     HAL_GPIO_WritePin(NSS_GPIO_Port,NSS_Pin,1);

// }
// #endif

// extern const uint16_t cal_firmware[MCU_AGC_FW_BYTE];
// extern const uint16_t arb_firmware[MCU_ARB_FW_BYTE] ;
// extern const uint16_t agc_firmware[MCU_AGC_FW_BYTE];
#if 1
// you must add the header file of tms570ls1224 driver
#include "spi.h"
#include "gio.h"
#include "can.h"
// #include "pin_config.h"
extern void Delay(volatile int time);
typedef struct _RfSpiPinConfig {
    spiBASE_t* reg;
    gioPORT_t* csport;
    uint32 cs;
    gioPORT_t* rstport;
    uint32 reset;
}RF_SPI_PIN_CONFIG_TYPE;

RF_SPI_PIN_CONFIG_TYPE sx1301_rf_pin = {
    spiREG4, spiPORT4, SPI_PIN_CS0,  gioPORTA,  5
};
void host_spi_select(void)
{
    gioSetBit(sx1301_rf_pin.csport, sx1301_rf_pin.cs, 0);
}
void host_spi_release(void)
{
    gioSetBit(sx1301_rf_pin.csport, sx1301_rf_pin.cs, 1);
}

void sx1302_reset(void)
{
    gioSetBit(sx1301_rf_pin.rstport, sx1301_rf_pin.reset, 1);
    Delay(200);
    gioSetBit(sx1301_rf_pin.rstport, sx1301_rf_pin.reset, 0);
    Delay(200);
}

BOB_Status_t BOB_HOSTSPI_WriteRead( uint8_t* txData ,uint8_t* rxData, uint16_t len, uint16_t Timeout)
{
    spiDAT1_t dataconfig1_t;
    dataconfig1_t.CS_HOLD = FALSE;
    dataconfig1_t.WDEL = TRUE;
    dataconfig1_t.DFSEL = SPI_FMT_1;                 /* PHASE is 1, POLARITY is 0, charlen is 8bit */
    dataconfig1_t.CSNR = (~sx1301_rf_pin.cs) & 0xFF; /* Chip select */
    uint16 tx,rx;
    int i;

    // gioSetBit(sx1301_rf_pin.csport, sx1301_rf_pin.cs, 0);
    for ( i = 0; i < len; i++)
    {
        tx=txData[i];
        spiTransmitAndReceiveData(sx1301_rf_pin.reg, &dataconfig1_t, 1, &tx, &rx);
        rxData[i]=(uint8_t)(rx&0xff);
    }

    // gioSetBit(sx1301_rf_pin.csport, sx1301_rf_pin.cs, 1);
    return 0;
}
// basic operation of spi
//-------------basic spi driver---------------
//--------------------------------------------
uint8 vSpiRead(uint8 reg)
{
    spiDAT1_t dataconfig1_t;
    uint16 spi_data;
    uint16 data = 0;

    dataconfig1_t.CS_HOLD = FALSE;
    dataconfig1_t.WDEL = TRUE;
    dataconfig1_t.DFSEL = SPI_FMT_0;    /* PHASE is 1, POLARITY is 0, charlen is 16bit */
    dataconfig1_t.CSNR = (~sx1301_rf_pin.cs) & 0xFF;   /* Chip select */

    spi_data = (reg << 8);
    gioSetBit(sx1301_rf_pin.csport, sx1301_rf_pin.cs, 0);
    spiTransmitAndReceiveData(sx1301_rf_pin.reg, &dataconfig1_t, 1, &spi_data, &data);
    gioSetBit(sx1301_rf_pin.csport, sx1301_rf_pin.cs, 1);
    return (data & 0xFF);
}

void vSpiWrite(uint8 reg, uint8 data)
{
    spiDAT1_t dataconfig1_t;
    uint16 spi_data;

    dataconfig1_t.CS_HOLD = FALSE;
    dataconfig1_t.WDEL = TRUE;
    dataconfig1_t.DFSEL = SPI_FMT_0;     /* PHASE is 1, POLARITY is 0, charlen is 16bit */
    dataconfig1_t.CSNR = (~sx1301_rf_pin.cs) & 0xFF;   /* Chip select */

    spi_data = ((reg << 8) | 0x8000) | data;
    gioSetBit(sx1301_rf_pin.csport, sx1301_rf_pin.cs, 0);
    spiTransmitData(sx1301_rf_pin.reg, &dataconfig1_t, 1, &spi_data);
    gioSetBit(sx1301_rf_pin.csport, sx1301_rf_pin.cs, 1);
}

void vSpiBurstRead(uint8 reg, uint8* msg, uint32 len)
{
    int i;
    if(msg == NULL){
        return ;
    }
    spiDAT1_t dataconfig1_t;
    uint16 addr;
    uint16 spi_burst_data;

    dataconfig1_t.CS_HOLD = FALSE;
    dataconfig1_t.WDEL = TRUE;
    dataconfig1_t.DFSEL = SPI_FMT_1;    /* PHASE is 1, POLARITY is 0, charlen is 8bit */
    dataconfig1_t.CSNR = (~sx1301_rf_pin.cs) & 0xFF;   /* Chip select */

    addr = reg;
    gioSetBit(sx1301_rf_pin.csport, sx1301_rf_pin.cs, 0);
    spiTransmitAndReceiveData(sx1301_rf_pin.reg, &dataconfig1_t, 1, &addr, &spi_burst_data);
    for(i = 0; i < len; i++){
        spiTransmitAndReceiveData(sx1301_rf_pin.reg, &dataconfig1_t, 1, &addr, &spi_burst_data);
        msg[i] = spi_burst_data ;
    }
    gioSetBit(sx1301_rf_pin.csport, sx1301_rf_pin.cs, 1);

}

void vSpiBurstWrite(uint8 reg, uint8* msg, uint32 len)
{
    spiDAT1_t dataconfig1_t;
    uint16 addr;
    uint16 spi_burst_data;

    int i;
    if(msg == NULL){
        return ;
    }

    dataconfig1_t.CS_HOLD = FALSE;
    dataconfig1_t.WDEL = TRUE;
    dataconfig1_t.DFSEL = SPI_FMT_1;     /* PHASE is 1, POLARITY is 0, charlen is 8bit */
    dataconfig1_t.CSNR = (~sx1301_rf_pin.cs) & 0xFF;   /* Chip select */

    addr = reg | 0x80;
    gioSetBit(sx1301_rf_pin.csport, sx1301_rf_pin.cs, 0);
    spiTransmitData(sx1301_rf_pin.reg, &dataconfig1_t, 1, &addr);

    for(i = 0; i < len; i++){
        spi_burst_data = msg[i];
        spiTransmitData(sx1301_rf_pin.reg, &dataconfig1_t, 1, &spi_burst_data);
    }
    gioSetBit(sx1301_rf_pin.csport, sx1301_rf_pin.cs, 1);

}
void vSpiBurstWriteFw(uint8 reg, uint16* msg, uint32 len)
{
    spiDAT1_t dataconfig1_t;
    uint16 addr;

    if(msg == NULL){
        return ;
    }

    dataconfig1_t.CS_HOLD = FALSE;
    dataconfig1_t.WDEL = TRUE;
    dataconfig1_t.DFSEL = SPI_FMT_1;     /* PHASE is 1, POLARITY is 0, charlen is 8bit */
    dataconfig1_t.CSNR = (~sx1301_rf_pin.cs) & 0xFF;   /* Chip select */

    addr = reg | 0x80;
    gioSetBit(sx1301_rf_pin.csport, sx1301_rf_pin.cs, 0);
    spiTransmitData(sx1301_rf_pin.reg, &dataconfig1_t, 1, &addr);
    spiTransmitData(sx1301_rf_pin.reg, &dataconfig1_t, len, msg);
    gioSetBit(sx1301_rf_pin.csport, sx1301_rf_pin.cs, 1);

}

#endif



int test_loragw_spi(void)
{
    int i;
    void *spi_target = NULL;
    uint8_t data = 0;
    uint8_t dataout[BURST_TEST_SIZE];
    uint8_t datain[BURST_TEST_SIZE];
    uint8_t spi_mux_mode = LGW_SPI_MUX_MODE0;

    for (i = 0; i < BURST_TEST_SIZE; ++i) {
        dataout[i] = 0x30 + (i % 10); /* ASCCI code for 0 -> 9 */
        datain[i] = 0x23; /* garbage data, to be overwritten by received data */
    }

    printf("Beginning of test for loragw_spi.c\n");
    lgw_spi_open(&spi_target);

    /* normal R/W test */
    for (i = 0; i < TIMING_REPEAT; ++i)
        lgw_spi_w(spi_target, spi_mux_mode, LGW_SPI_MUX_TARGET_SX1301, 0xAA, 0x96);
    for (i = 0; i < TIMING_REPEAT; ++i)
        lgw_spi_r(spi_target, spi_mux_mode, LGW_SPI_MUX_TARGET_SX1301, 0x55, &data);
        printf("read spi from 0x55 is 0x%02x\n",data);

    /* burst R/W test, small bursts << LGW_BURST_CHUNK */
    for (i = 0; i < TIMING_REPEAT; ++i)
        lgw_spi_wb(spi_target, spi_mux_mode, LGW_SPI_MUX_TARGET_SX1301, 0x55, dataout, 16);
    for (i = 0; i < TIMING_REPEAT; ++i)
        lgw_spi_rb(spi_target, spi_mux_mode, LGW_SPI_MUX_TARGET_SX1301, 0x55, datain, 16);

    printf("burst read spi from 0x55 is:");  
     for (i = 0; i < 16; ++i)
        printf("%02x ",datain[i]);
    printf("\n");

    /* burst R/W test, large bursts >> LGW_BURST_CHUNK */
    for (i = 0; i < TIMING_REPEAT; ++i)
        lgw_spi_wb(spi_target, spi_mux_mode, LGW_SPI_MUX_TARGET_SX1301, 0x5A, dataout, ARRAY_SIZE(dataout));
    for (i = 0; i < TIMING_REPEAT; ++i)
        lgw_spi_rb(spi_target, spi_mux_mode, LGW_SPI_MUX_TARGET_SX1301, 0x5A, datain, ARRAY_SIZE(datain));

    printf("burst read spi from 0x5a is:");  
    for (i = 0; i < 250; ++i)
        printf("%02x ",datain[i]);

    printf("\n");

    /* last read (blocking), just to be sure no to quit before the FTDI buffer is flushed */
    lgw_spi_r(spi_target, spi_mux_mode, LGW_SPI_MUX_TARGET_SX1301, 0x55, &data);
    printf("data received (simple read 0x55): %d\n",data);

    lgw_spi_close(spi_target);
    printf("End of test for loragw_spi.c\n");

    return 0;
}

int test_loragw_reg(void)
{
    int32_t read_value, test_value;
    uint16_t lfsr;
    uint8_t burst_buffout[BURST_TEST_LENGTH];
    uint8_t burst_buffin[BURST_TEST_LENGTH];
    int i;

    printf("Beginning of test for loragw_reg.c\n");

    lgw_connect(false, 129E3);
    /* 2 SPI transactions:
    -> 0x80 0x00        <- 0x00 0x00        forcing page 0
    -> 0x01 0x00        <- 0x00 0x64        checking version
    */

    /* --- READ TEST --- */

    lgw_reg_w(LGW_SOFT_RESET, 1);
    lgw_reg_check();

    /* --- READ/WRITE COHERENCY TEST --- */

    /* 8b unsigned */
    test_value = 197; /* 11000101b */
    lgw_reg_w(LGW_IMPLICIT_PAYLOAD_LENGHT, test_value);
    lgw_reg_r(LGW_IMPLICIT_PAYLOAD_LENGHT, &read_value);
    printf("IMPLICIT_PAYLOAD_LENGHT = %d (should be %d)\n", read_value, test_value);

    /* 8b signed */
    /* NO SUCH REG AVAILABLE */
    // /* RADIO_SELECT is normally unsigned, modify it manually in loragw_reg.c */
    // test_value = -59; /* 11000101b */
    // lgw_reg_w(LGW_RADIO_SELECT, test_value);
    // lgw_reg_r(LGW_RADIO_SELECT, &read_value);
    // printf("RADIO_SELECT = %d (should be %d)\n", read_value, test_value);

    /* less than 8b, with offset, unsigned */
    test_value = 11; /* 1011b */
    lgw_reg_w(LGW_FRAME_SYNCH_PEAK2_POS, test_value);
    lgw_reg_r(LGW_FRAME_SYNCH_PEAK2_POS, &read_value);
    printf("FRAME_SYNCH_PEAK2_POS = %d (should be %d)\n", read_value, test_value);

    /* less than 8b, with offset, signed */
    /* NO SUCH REG AVAILABLE */
    // /* MBWSSF_FRAME_SYNCH_PEAK2_POS is normally unsigned, modify it manually in loragw_reg.c */
    // test_value = -5; /* 1011b */
    // lgw_reg_w(LGW_MBWSSF_FRAME_SYNCH_PEAK2_POS, test_value);
    // lgw_reg_r(LGW_MBWSSF_FRAME_SYNCH_PEAK2_POS, &read_value);
    // printf("MBWSSF_FRAME_SYNCH_PEAK2_POS = %d (should be %d)\n", read_value, test_value);

    /* 16b unsigned */
    test_value = 49253; /* 11000000 01100101b */
    lgw_reg_w(LGW_PREAMBLE_SYMB1_NB, test_value);
    lgw_reg_r(LGW_PREAMBLE_SYMB1_NB, &read_value);
    printf("PREAMBLE_SYMB1_NB = %d (should be %d)\n", read_value, test_value);

    /* 16b signed */
    /* NO SUCH REG AVAILABLE */
    // /* CAPTURE_PERIOD is normally unsigned, modify it manually in loragw_reg.c */
    // test_value = -16283; /* 11000000 01100101b */
    // lgw_reg_w(LGW_CAPTURE_PERIOD, test_value);
    // lgw_reg_r(LGW_CAPTURE_PERIOD, &read_value);
    // printf("CAPTURE_PERIOD = %d (should be %d)\n", read_value, test_value);

    /* between 8b and 16b, unsigned */
    test_value = 3173; /* 1100 01100101b */
    lgw_reg_w(LGW_ADJUST_MODEM_START_OFFSET_SF12_RDX4, test_value);
    lgw_reg_r(LGW_ADJUST_MODEM_START_OFFSET_SF12_RDX4, &read_value);
    printf("ADJUST_MODEM_START_OFFSET_SF12_RDX4 = %d (should be %d)\n", read_value, test_value);

    /* between 8b and 16b, signed */
    test_value = -1947; /* 11000 01100101b */
    lgw_reg_w(LGW_IF_FREQ_1, test_value);
    lgw_reg_r(LGW_IF_FREQ_1, &read_value);
    printf("IF_FREQ_1 = %d (should be %d)\n", read_value, test_value);

    /* --- BURST WRITE AND READ TEST --- */

    /* initialize data for SPI test */
    lfsr = 0xFFFF;
    for(i=0; i<BURST_TEST_LENGTH; ++i) {
        burst_buffout[i] = (uint8_t)(lfsr ^ (lfsr >> 4));
        /* printf("%05d # 0x%04x 0x%02x\n", i, lfsr, burst_buffout[i]); */
        lfsr = (lfsr & 1) ? ((lfsr >> 1) ^ 0x8679) : (lfsr >> 1);
    }

    lgw_reg_wb(LGW_TX_DATA_BUF_DATA, burst_buffout, 256);
    lgw_reg_rb(LGW_RX_DATA_BUF_DATA, burst_buffin, 256);

    /* impossible to check in software,
    RX_DATA_BUF_DATA is read-only,
    TX_DATA_BUF_DATA is write only,
    use a logic analyser */

    /* --- END OF TEST --- */

    lgw_disconnect();
    /* no SPI transaction */

    printf("End of test for loragw_reg.c\n");
    return 0;


}

/* -------------------------------------------------------------------------- */
/* --- MACROS & CONSTANTS --------------------------------------------------- */

// #define ARRAY_SIZE(a) (sizeof(a) / sizeof((a)[0]))
#define MSG   printf
// #define MSG(args...) fprintf(, args) /* message that is destined to the user */

#define TX_RF_CHAIN             0    /* TX only supported on radio A */
#define DEFAULT_RSSI_OFFSET     0.0

#define DEFAULT_FREQ_HZ         868e6
#define DEFAULT_DIGITAL_GAIN    0
#define DEFAULT_DAC_GAIN        3
#define DEFAULT_MIXER_GAIN      14
#define DEFAULT_PA_GAIN         3
#define DEFAULT_MODULATION      "LORA"
#define DEFAULT_SF              7
#define DEFAULT_BW_KHZ          125
#define DEFAULT_BR_KBPS         50
#define DEFAULT_FDEV_KHZ        25
#define DEFAULT_BT              2
#define DEFAULT_NOTCH_FREQ      129000U

// printf(" -f      <float>  Tx RF frequency in MHz [800:1000]\n");
// printf(" -r      <int>    Radio type (SX1255:1255, SX1257:1257)\n");
// printf(" --notch <uint>   Tx notch filter frequency in KhZ [126..250]\n");
// printf(" --dig   <uint>   Digital gain trim, [0:3]\n");
// printf("                   0:1, 1:7/8, 2:3/4, 3:1/2\n");
// printf(" --mix   <uint>   Radio Tx mixer gain trim, [0:15]\n");
// printf("                   15 corresponds to maximum gain, 1 LSB corresponds to 2dB step\n");
// printf(" --pa    <uint>   PA gain trim, [0:3]\n");
// printf(" --mod   <char>   Modulation type ['LORA','FSK','CW']\n");
// printf(" --sf    <uint>   LoRa Spreading Factor, [7:12]\n");
// printf(" --bw    <uint>   LoRa bandwidth in kHz, [125,250,500]\n");
// printf(" --br    <float>  FSK bitrate in kbps, [0.5:250]\n");
// printf(" --fdev  <uint>   FSK frequency deviation in kHz, [1:250]\n");
// printf(" --bt    <uint>   FSK gaussian filter BT trim, [0:3]\n");

int test_loragw_cw(void)
{
   
    int i; /* loop and temporary variables */

    /* Parameter parsing */
    int option_index = 0;
  
    unsigned int arg_u;
    float arg_f;
    char arg_s[64];

    /* Application parameters */
    uint32_t freq_hz = DEFAULT_FREQ_HZ;
    uint8_t g_dig = DEFAULT_DIGITAL_GAIN;
    uint8_t g_dac = DEFAULT_DAC_GAIN;
    uint8_t g_mix = DEFAULT_MIXER_GAIN;
    uint8_t g_pa = DEFAULT_PA_GAIN;
    char mod[64] = DEFAULT_MODULATION;
    uint8_t sf = DEFAULT_SF;
    unsigned int bw_khz = DEFAULT_BW_KHZ;
    float br_kbps = DEFAULT_BR_KBPS;
    uint8_t fdev_khz = DEFAULT_FDEV_KHZ;
    uint8_t bt = DEFAULT_BT;
    uint32_t tx_notch_freq = DEFAULT_NOTCH_FREQ;

    int32_t offset_i, offset_q;

    /* RF configuration (TX fail if RF chain is not enabled) */
    enum lgw_radio_type_e radio_type = LGW_RADIO_TYPE_SX1257;
    struct lgw_conf_board_s boardconf;
    struct lgw_conf_rxrf_s rfconf;
    struct lgw_tx_gain_lut_s txlut;
    struct lgw_pkt_tx_s txpkt;

    g_dig = (uint8_t)0;  //[0..3]
    g_dac = (uint8_t)0;  //  [0..3]
    g_mix = (uint8_t)15; //[0:15]\n");
    g_pa = 3;            //[0..3]
    sprintf(mod, "%s", "CW");
    sf = (uint8_t)7;                       //[7..12]
    bw_khz = 250;                          // LoRa bandwidth in kHz, [125,250,500]\n");
    br_kbps = 50;                          //[0.5..250]
    fdev_khz = (uint8_t)250;               //[1..250]
    bt = (uint8_t)0;                       //[0..3]
    tx_notch_freq = (uint32_t)200 * 1000U; // [126..250]
    g_dig = (uint8_t)0;                    //[0..3]
    freq_hz = (uint32_t)((490.0 * 1e6) + 0.5);
    radio_type = LGW_RADIO_TYPE_SX1255;

    /* Board config */
    memset(&boardconf, 0, sizeof(boardconf));
    boardconf.lorawan_public = true;
    boardconf.clksrc = 1; /* Radio B is source by default */
    lgw_board_setconf(boardconf);

    /* RF config */
    memset(&rfconf, 0, sizeof(rfconf));
    rfconf.enable = true;
    rfconf.freq_hz = freq_hz;
    rfconf.rssi_offset = DEFAULT_RSSI_OFFSET;
    rfconf.type = radio_type;
    rfconf.tx_enable = true;
    rfconf.tx_notch_freq = tx_notch_freq;
    lgw_rxrf_setconf(TX_RF_CHAIN, rfconf);

    /* Tx gain LUT */
    memset(&txlut, 0, sizeof txlut);
    txlut.size = 1;
    txlut.lut[0].dig_gain = g_dig;
    txlut.lut[0].pa_gain = g_pa;
    txlut.lut[0].dac_gain = g_dac;
    txlut.lut[0].mix_gain = g_mix;
    txlut.lut[0].rf_power = 0;
    lgw_txgain_setconf(&txlut);

    /* Start the concentrator */
    i = lgw_start();
    if (i == LGW_HAL_SUCCESS) {
        MSG("INFO: concentrator started, packet can be sent\n");
    } else {
        MSG("ERROR: failed to start the concentrator\n");
        return EXIT_FAILURE;
    }

    /* fill-up payload and parameters */
    memset(&txpkt, 0, sizeof(txpkt));
    txpkt.freq_hz = freq_hz;
    txpkt.tx_mode = IMMEDIATE;
    txpkt.rf_chain = TX_RF_CHAIN;
    txpkt.rf_power = 0;
    if (strcmp(mod, "FSK") == 0) {
        txpkt.modulation = MOD_FSK;
        txpkt.datarate = br_kbps * 1e3;
    } else {
        txpkt.modulation = MOD_LORA;
        switch (bw_khz) {
            case 125: txpkt.bandwidth = BW_125KHZ; break;
            case 250: txpkt.bandwidth = BW_250KHZ; break;
            case 500: txpkt.bandwidth = BW_500KHZ; break;
            default:
                MSG("ERROR: invalid 'bw' variable\n");
                return EXIT_FAILURE;
        }
        switch (sf) {
            case  7: txpkt.datarate = DR_LORA_SF7;  break;
            case  8: txpkt.datarate = DR_LORA_SF8;  break;
            case  9: txpkt.datarate = DR_LORA_SF9;  break;
            case 10: txpkt.datarate = DR_LORA_SF10; break;
            case 11: txpkt.datarate = DR_LORA_SF11; break;
            case 12: txpkt.datarate = DR_LORA_SF12; break;
            default:
                MSG("ERROR: invalid 'sf' variable\n");
                return EXIT_FAILURE;
        }
    }
    txpkt.coderate = CR_LORA_4_5;
    txpkt.f_dev = fdev_khz;
    txpkt.preamble = 65535;
    txpkt.invert_pol = false;
    txpkt.no_crc = true;
    txpkt.no_header = true;
    txpkt.size = 1;
    txpkt.payload[0] = 0;

    /* Overwrite settings */
    lgw_reg_w(LGW_TX_MODE, 1); /* Tx continuous */
    lgw_reg_w(LGW_FSK_TX_GAUSSIAN_SELECT_BT, bt);
    if (strcmp(mod, "CW") == 0) {
        /* Enable signal generator with DC */
        lgw_reg_w(LGW_SIG_GEN_FREQ, 0);
        lgw_reg_w(LGW_SIG_GEN_EN, 1);
        lgw_reg_w(LGW_TX_OFFSET_I, 0);
        lgw_reg_w(LGW_TX_OFFSET_Q, 0);
    }

    /* Send packet */
    i = lgw_send(txpkt);

    /* Recap all settings */
    printf("SX1301 library version: %s\n", lgw_version_info());
    if (strcmp(mod, "LORA") == 0) {
        printf("Modulation: LORA SF:%d BW:%d kHz\n", sf, bw_khz);
    }
    else if (strcmp(mod, "FSK") == 0) {
        printf("Modulation: FSK BR:%3.3f kbps FDEV:%d kHz BT:%d\n", br_kbps, fdev_khz, bt);
    }
    else if (strcmp(mod, "CW") == 0) {
        printf("Modulation: CW\n");
    }
    switch(rfconf.type) {
        case LGW_RADIO_TYPE_SX1255:
            printf("Radio Type: SX1255\n");
            break;
        case LGW_RADIO_TYPE_SX1257:
            printf("Radio Type: SX1257\n");
            break;
        default:
            printf("ERROR: undefined radio type\n");
            break;
    }
    printf("Frequency: %4.3f MHz\n", freq_hz/1e6);
    printf("TX Gains: Digital:%d DAC:%d Mixer:%d PA:%d\n", g_dig, g_dac, g_mix, g_pa);
    if (strcmp(mod, "CW") != 0) {
        lgw_reg_r(LGW_TX_OFFSET_I, &offset_i);
        lgw_reg_r(LGW_TX_OFFSET_Q, &offset_q);
        printf("Calibrated DC offsets: I:%d Q:%d\n", offset_i, offset_q);
    }

    /* waiting for user input */
    while (1) {
        wait_ms(100);
    }

    /* clean up before leaving */
    lgw_stop();

    return 0;
}






