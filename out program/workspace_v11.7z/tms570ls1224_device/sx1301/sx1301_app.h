#ifndef _____SX1301_APP_H_____
#define _____SX1301_APP_H_____

#include "loragw_spi.h"
#include "loragw_reg.h"
#include <stdint.h>

#define EXIT_SUCCESS 0
#define EXIT_FAILURE 1

typedef enum
{
  BOB_OK       = 0x00,
  BOB_ERROR    = 0x01,
  BOB_BUSY     = 0x02,
  BOB_TIMEOUT  = 0x03
} BOB_Status_t;

// low level spi driver
BOB_Status_t BOB_HOSTSPI_WriteRead( uint8_t* txData ,uint8_t* rxData, uint16_t len, uint16_t Timeout);
void host_spi_select(void);
void host_spi_release(void);
void sx1302_reset(void);

int test_loragw_spi(void);
int test_loragw_reg(void);
int test_loragw_cw(void);


int tx_test(void);
int rx_test(void);

#if 1
#include <hal_stdtypes.h>

uint8 vSpiRead(uint8 reg);
void vSpiWrite(uint8 reg, uint8 data);
void vSpiBurstRead(uint8 reg, uint8* msg, uint32 len);
void vSpiBurstWrite(uint8 reg, uint8* msg, uint32 len);
void vSpiBurstWriteFw(uint8 reg, uint16* msg, uint32 len);
#endif


#endif
