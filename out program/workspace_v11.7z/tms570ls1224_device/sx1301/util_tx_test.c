#include "sx1301_app.h"

#include "loragw_hal.h"
#include "loragw_reg.h"
#include "loragw_aux.h"

/* -------------------------------------------------------------------------- */
/* --- PRIVATE MACROS ------------------------------------------------------- */

#define ARRAY_SIZE(a) (sizeof(a) / sizeof((a)[0]))
#define MSG printf
// #define MSG(args...) fprintf(stderr, args) /* message that is destined to the user */

/* -------------------------------------------------------------------------- */
/* --- PRIVATE CONSTANTS ---------------------------------------------------- */

#define TX_RF_CHAIN                 0 /* TX only supported on radio A */
#define DEFAULT_RSSI_OFFSET         0.0
#define DEFAULT_MODULATION          "LORA"
#define DEFAULT_BR_KBPS             50
#define DEFAULT_FDEV_KHZ            25
#define DEFAULT_NOTCH_FREQ          129000U /* 129 kHz */
#define DEFAULT_SX127X_RSSI_OFFSET  -4 /* dB */

/* -------------------------------------------------------------------------- */
/* --- PRIVATE VARIABLES (GLOBAL) ------------------------------------------- */


/* TX gain LUT table */
static struct lgw_tx_gain_lut_s txgain_lut = {
    .size = 5,
    .lut[0] = {
        .dig_gain = 0,
        .pa_gain = 0,
        .dac_gain = 3,
        .mix_gain = 12,
        .rf_power = 0
    },
    .lut[1] = {
        .dig_gain = 0,
        .pa_gain = 1,
        .dac_gain = 3,
        .mix_gain = 12,
        .rf_power = 10
    },
    .lut[2] = {
        .dig_gain = 0,
        .pa_gain = 2,
        .dac_gain = 3,
        .mix_gain = 10,
        .rf_power = 14
    },
    .lut[3] = {
        .dig_gain = 0,
        .pa_gain = 3,
        .dac_gain = 3,
        .mix_gain = 9,
        .rf_power = 20
    },
    .lut[4] = {
        .dig_gain = 0,
        .pa_gain = 3,
        .dac_gain = 3,
        .mix_gain = 14,
        .rf_power = 27
    }};

/* -------------------------------------------------------------------------- */
/* --- PRIVATE FUNCTIONS DECLARATION ---------------------------------------- */



// void usage (void);
/* describe command line options */
// void usage(void) {
//     int i;

//     printf("*** Library version information ***\n%s\n\n", lgw_version_info());
//     printf("Available options:\n");
//     printf(" -h                 print this help\n");
//     printf(" -r         <int>   radio type (SX1255:1255, SX1257:1257)\n");
//     printf(" -n         <uint>  TX notch filter frequency in kHz [126..250]\n");
//     printf(" -f         <float> target frequency in MHz\n");
//     printf(" -k         <uint>  concentrator clock source (0:Radio A, 1:Radio B)\n");
//     printf(" -m         <str>   modulation type ['LORA', 'FSK']\n");
//     printf(" -b         <uint>  LoRa bandwidth in kHz [125, 250, 500]\n");
//     printf(" -s         <uint>  LoRa Spreading Factor [7-12]\n");
//     printf(" -c         <uint>  LoRa Coding Rate [1-4]\n");
//     printf(" -d         <uint>  FSK frequency deviation in kHz [1:250]\n");
//     printf(" -q         <float> FSK bitrate in kbps [0.5:250]\n");
//     printf(" -p         <int>   RF power (dBm) [ ");
//     for (i = 0; i < txgain_lut.size; i++) {
//         printf("%ddBm ", txgain_lut.lut[i].rf_power);
//     }
//     printf("]\n");
//     printf(" -l         <uint>  LoRa preamble length (symbols)\n");
//     printf(" -z         <uint>  payload size (bytes, <256)\n");
//     printf(" -i                 send packet using inverted modulation polarity\n");
//     printf(" -t         <uint>  pause between packets (ms)\n");
//     printf(" -x         <int>   nb of times the sequence is repeated (-1 loop until stopped)\n");
//     printf(" --lbt-freq         <float> lbt first channel frequency in MHz\n");
//     printf(" --lbt-nbch         <uint>  lbt number of channels [1..8]\n");
//     printf(" --lbt-sctm         <uint>  lbt scan time in usec to be applied to all channels [128, 5000]\n");
//     printf(" --lbt-rssi         <int>   lbt rssi target in dBm [-128..0]\n");
//     printf(" --lbt-rssi-offset  <int>   rssi offset in dB to be applied to SX127x RSSI [-128..127]\n");
// }

/* -------------------------------------------------------------------------- */
/* --- MAIN FUNCTION -------------------------------------------------------- */

int tx_test(void)
{
    int i;
    uint8_t status_var;

    /* user entry parameters */
    int xi = 0;
    unsigned int xu = 0;
    double xd = 0.0;
    float xf = 0.0;
    char arg_s[64];

    /* application parameters */
    char mod[64] = DEFAULT_MODULATION;
    uint32_t f_target = 0; /* target frequency - invalid default value, has to be specified by user */
    int sf = 10; /* SF10 by default */
    int cr = 1; /* CR1 aka 4/5 by default */
    int bw = 125; /* 125kHz bandwidth by default */
    int pow = 14; /* 14 dBm by default */
    int preamb = 8; /* 8 symbol preamble by default */
    int pl_size = 16; /* 16 bytes payload by default */
    int delay = 1000; /* 1 second between packets by default */
    int repeat = -1; /* by default, repeat until stopped */
    bool invert = false;
    float br_kbps = DEFAULT_BR_KBPS;
    uint8_t fdev_khz = DEFAULT_FDEV_KHZ;
    bool lbt_enable = false;
    uint32_t lbt_f_target = 0;
    uint32_t lbt_sc_time = 5000;
    int8_t lbt_rssi_target_dBm = -80;
    int8_t lbt_rssi_offset_dB = DEFAULT_SX127X_RSSI_OFFSET;
    uint8_t  lbt_nb_channel = 1;
    uint32_t sx1301_count_us;
    uint32_t tx_notch_freq = DEFAULT_NOTCH_FREQ;

    /* RF configuration (TX fail if RF chain is not enabled) */
    enum lgw_radio_type_e radio_type = LGW_RADIO_TYPE_NONE;
    uint8_t clocksource = 1; /* Radio B is source by default */
    struct lgw_conf_board_s boardconf;
    struct lgw_conf_lbt_s lbtconf;
    struct lgw_conf_rxrf_s rfconf;

    /* allocate memory for packet sending */
    struct lgw_pkt_tx_s txpkt; /* array containing 1 outbound packet + metadata */

    /* loop variables (also use as counters in the packet payload) */
    uint16_t cycle_count = 0;

    

    /* parse command line options */
    f_target=(uint32_t)((490.0*1e6) + 0.5); // <float> Target frequency in MHz[30..3000]
    tx_notch_freq=200*1000;//TX notch filter frequency in kHz[126..250]
    sprintf(mod, "%s", "LORA"); // LORA or FSK               
    bw = 125;//Modulation bandwidth in kHz[125.250.500]
    sf=7;//Spreading Factor[7..12]
    cr=1;//Coding Rate[1..4]
    pow=50;//<int> RF power[-60..60]
    fdev_khz=10;//<uint> FSK frequency deviation[1..250]
    br_kbps=10;//<float> FSK bitrate [0.5..250]
    preamb=12;//<uint> preamble length (symbols)
    pl_size=21;//payload length (bytes)
    delay=1000;//pause between packets (ms)
    repeat=-1;//<int> numbers of times the sequence is repeated
    radio_type = LGW_RADIO_TYPE_SX1255;
    invert = false;//Send packet using inverted modulation polarity
    clocksource = (uint8_t)1;// Concentrator clock source (Radio A or Radio B)
    lbt_f_target = (uint32_t)((1000*1e6) + 0.5);//[30..3000]
    lbt_enable = false;
    // lbt_f_target = (uint32_t)((xd*1e6) + 0.5); /* .5 Hz offset to get rounding instead of truncating */
    // lbt_enable = true;
    lbt_sc_time=100;//LBT scan time in usec
    lbt_rssi_target_dBm=0;//[-128..0]
    lbt_rssi_offset_dB=0;//[-128..127]
    lbt_nb_channel=10;
    /* check parameter sanity */
    if (f_target == 0) {
        MSG("ERROR: frequency parameter not set, please use -f option to specify it.\n");
        return EXIT_FAILURE;
    }
    if (radio_type == LGW_RADIO_TYPE_NONE) {
        MSG("ERROR: radio type parameter not properly set, please use -r option to specify it.\n");
        return EXIT_FAILURE;
    }

    /* Summary of packet parameters */
    if (strcmp(mod, "FSK") == 0) {
        printf("Sending %i FSK packets on %u Hz (FDev %u kHz, Bitrate %.2f, %i bytes payload, %i symbols preamble) at %i dBm, with %i ms between each\n", repeat, f_target, fdev_khz, br_kbps, pl_size, preamb, pow, delay);
    } else {
        printf("Sending %i LoRa packets on %u Hz (BW %i kHz, SF %i, CR %i, %i bytes payload, %i symbols preamble) at %i dBm, with %i ms between each\n", repeat, f_target, bw, sf, cr, pl_size, preamb, pow, delay);
    }

    /* starting the concentrator */
    /* board config */
    memset(&boardconf, 0, sizeof(boardconf));
    boardconf.lorawan_public = false;
    boardconf.clksrc = clocksource;
    lgw_board_setconf(boardconf);

    /* LBT config */
    // if (lbt_enable) {
    //     memset(&lbtconf, 0, sizeof(lbtconf));
    //     lbtconf.enable = true;
    //     lbtconf.nb_channel = lbt_nb_channel;
    //     lbtconf.rssi_target = lbt_rssi_target_dBm;
    //     lbtconf.rssi_offset = lbt_rssi_offset_dB;
    //     lbtconf.channels[0].freq_hz = lbt_f_target;
    //     lbtconf.channels[0].scan_time_us = lbt_sc_time;
    //     for (i=1; i<lbt_nb_channel; i++) {
    //         lbtconf.channels[i].freq_hz = lbtconf.channels[i-1].freq_hz + 200E3; /* 200kHz offset for all channels */
    //         lbtconf.channels[i].scan_time_us = lbt_sc_time;
    //     }
    //     lgw_lbt_setconf(lbtconf);
    // }

    /* RF config */
    memset(&rfconf, 0, sizeof(rfconf));
    rfconf.enable = true;
    rfconf.freq_hz = f_target;
    rfconf.rssi_offset = DEFAULT_RSSI_OFFSET;
    rfconf.type = radio_type;
    for (i = 0; i < LGW_RF_CHAIN_NB; i++) {
        if (i == TX_RF_CHAIN) {
            rfconf.tx_enable = true;
            rfconf.tx_notch_freq = tx_notch_freq;
        } else {
            rfconf.tx_enable = false;
        }
        lgw_rxrf_setconf(i, rfconf);
    }

    /* TX gain config */
    lgw_txgain_setconf(&txgain_lut);

    /* Start concentrator */
    i = lgw_start();
    if (i == LGW_HAL_SUCCESS) {
        MSG("INFO: concentrator started, packet can be sent\n");
    } else {
        MSG("ERROR: failed to start the concentrator\n");
        return EXIT_FAILURE;
    }

    /* fill-up payload and parameters */
    memset(&txpkt, 0, sizeof(txpkt));
    txpkt.freq_hz = f_target;
    if (lbt_enable == true) {
        txpkt.tx_mode = TIMESTAMPED;
    } else {
        txpkt.tx_mode = IMMEDIATE;
    }
    txpkt.rf_chain = TX_RF_CHAIN;
    txpkt.rf_power = pow;
    if( strcmp( mod, "FSK" ) == 0 ) {
        txpkt.modulation = MOD_FSK;
        txpkt.datarate = br_kbps * 1e3;
        txpkt.f_dev = fdev_khz;
    } else {
        txpkt.modulation = MOD_LORA;
        switch (bw) {
            case 125: txpkt.bandwidth = BW_125KHZ; break;
            case 250: txpkt.bandwidth = BW_250KHZ; break;
            case 500: txpkt.bandwidth = BW_500KHZ; break;
            default:
                MSG("ERROR: invalid 'bw' variable\n");
                return EXIT_FAILURE;
        }
        switch (sf) {
            case  7: txpkt.datarate = DR_LORA_SF7;  break;
            case  8: txpkt.datarate = DR_LORA_SF8;  break;
            case  9: txpkt.datarate = DR_LORA_SF9;  break;
            case 10: txpkt.datarate = DR_LORA_SF10; break;
            case 11: txpkt.datarate = DR_LORA_SF11; break;
            case 12: txpkt.datarate = DR_LORA_SF12; break;
            default:
                MSG("ERROR: invalid 'sf' variable\n");
                return EXIT_FAILURE;
        }
        switch (cr) {
            case 1: txpkt.coderate = CR_LORA_4_5; break;
            case 2: txpkt.coderate = CR_LORA_4_6; break;
            case 3: txpkt.coderate = CR_LORA_4_7; break;
            case 4: txpkt.coderate = CR_LORA_4_8; break;
            default:
                MSG("ERROR: invalid 'cr' variable\n");
                return EXIT_FAILURE;
        }
    }
    txpkt.invert_pol = invert;
    txpkt.preamble = preamb;
    txpkt.size = pl_size;
    //strcpy((char *)txpkt.payload, "my name is weijunfeng\n" ); /* abc.. is for padding */
    for ( i = 0; i < pl_size; i++)
    {
        txpkt.payload[i]=0x10+i;
    }
    
    // 

    /* main loop */
    cycle_count = 0;
    while ((repeat == -1) || (cycle_count < repeat)) {
        ++cycle_count;

        /* refresh counters in payload (big endian, for readability) */
        txpkt.payload[4] = (uint8_t)(cycle_count >> 8); /* MSB */
        txpkt.payload[5] = (uint8_t)(cycle_count & 0x00FF); /* LSB */

        /* When LBT is enabled, immediate send is not allowed, so we need
            to set a timestamp to the packet */
        if (lbt_enable == true) {
            /* Get the current SX1301 time */
            lgw_reg_w(LGW_GPS_EN, 0);
            lgw_get_trigcnt(&sx1301_count_us);
            lgw_reg_w(LGW_GPS_EN, 1);

            /* Set packet timestamp to current time + few milliseconds */
            txpkt.count_us = sx1301_count_us + 50E3;
        }

        /* send packet */
        printf("Sending packet number %u ...", cycle_count);
        i = lgw_send(txpkt); /* non-blocking scheduling of TX packet */
        if (i == LGW_HAL_ERROR) {
            printf("ERROR\n");
            return EXIT_FAILURE;
        } else if (i == LGW_LBT_ISSUE ) {
            printf("Failed: Not allowed (LBT)\n");
        } else {
            /* wait for packet to finish sending */
            do {
                wait_ms(5);
                lgw_status(TX_STATUS, &status_var); /* get TX status */
            } while (status_var != TX_FREE);
            printf("OK\n");
        }

        /* wait inter-packet delay */
        wait_ms(delay);

    }

    /* clean up before leaving */
    lgw_stop();

    printf("Exiting LoRa concentrator TX test program\n");
    return EXIT_SUCCESS;
}

/* --- EOF ------------------------------------------------------------------ */
