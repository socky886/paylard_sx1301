#include "sx1301_app.h"

#include "loragw_hal.h"
#include "loragw_reg.h"
#include "loragw_aux.h"

/* -------------------------------------------------------------------------- */
/* --- PRIVATE MACROS ------------------------------------------------------- */

#define ARRAY_SIZE(a) (sizeof(a) / sizeof((a)[0]))
#define MSG printf

/* -------------------------------------------------------------------------- */
/* --- PRIVATE VARIABLES (GLOBAL) ------------------------------------------- */



/* configuration variables needed by the application  */
uint64_t lgwm = 0; /* LoRa gateway MAC address */
char lgwm_str[17];

/* clock and log file management */
// time_t now_time;
// time_t log_start_time;


/* -------------------------------------------------------------------------- */
/* --- PRIVATE FUNCTIONS DECLARATION ---------------------------------------- */



int parse_SX1301_configuration(const char * conf_file);

int parse_gateway_configuration(const char * conf_file);

void open_log(void);

void usage (void);

/* -------------------------------------------------------------------------- */
/* --- PRIVATE FUNCTIONS DEFINITION ----------------------------------------- */
struct multiSF_conf
{
    bool enable;
    unsigned char rf_chain;
    int if_fre;
} IF_Conf[8] = {
    {true, 1, -400000},
    {true, 1, -200000},
    {true, 1, 0},
    {true, 0, -400000},
    {true, 0, -200000},
    {true, 0, 0},
    {true, 0, 200000},
    {true, 0, 400000}
};

int parse_SX1301_configuration(const char *conf_file)
{
    int i;
    // const char conf_obj[] = "SX1301_conf";
    // char param_name[32]; /* used to generate variable parameter names */
    // const char *str; /* used to store string value from JSON object */
    struct lgw_conf_board_s boardconf;
    struct lgw_conf_rxrf_s rfconf;
    struct lgw_conf_rxif_s ifconf;
    uint32_t sf, bw;

    

    /* set board configuration */
    memset(&boardconf, 0, sizeof boardconf); /* initialize configuration structure */
    boardconf.lorawan_public=false;
    boardconf.clksrc = 1;
    MSG("INFO: lorawan_public %d, clksrc %d\n", boardconf.lorawan_public, boardconf.clksrc);
    /* all parameters parsed, submitting configuration to the HAL */
    if (lgw_board_setconf(boardconf) != LGW_HAL_SUCCESS) {
        MSG("ERROR: Failed to configure board\n");
        return -1;
    }

    /* set configuration for RF chains */
    // for (i = 0; i < LGW_RF_CHAIN_NB; ++i)
    for (i = 0; i < 1; ++i)
    {
        memset(&rfconf, 0, sizeof(rfconf)); /* initialize configuration structure */
        rfconf.enable = true;
        rfconf.freq_hz = 490000000;
        rfconf.rssi_offset = -166.0;
        rfconf.type = LGW_RADIO_TYPE_SX1255;
        rfconf.tx_enable = false;
        rfconf.tx_notch_freq = 0; // tx notch filter frequency to be set
        printf("INFO: radio %i enabled (type SX1255), center frequency %u, RSSI offset %f, tx enabled %d, tx_notch_freq %u\n", i, rfconf.freq_hz, rfconf.rssi_offset, rfconf.tx_enable, rfconf.tx_notch_freq);
        /* all parameters parsed, submitting configuration to the HAL */
        if (lgw_rxrf_setconf(i, rfconf) != LGW_HAL_SUCCESS)
        {
            MSG("ERROR: invalid configuration for radio %i\n", i);
            return -1;
        }

    }

    for (i = 1; i < LGW_RF_CHAIN_NB; ++i)
    {
        memset(&rfconf, 0, sizeof(rfconf)); /* initialize configuration structure */
        rfconf.enable = true;
        rfconf.freq_hz = 495000000;
        rfconf.rssi_offset = -166.0;
        rfconf.type = LGW_RADIO_TYPE_SX1255;
        rfconf.tx_enable = false;
        rfconf.tx_notch_freq = 0; // tx notch filter frequency to be set
        printf("INFO: radio %i enabled (type SX1255), center frequency %u, RSSI offset %f, tx enabled %d, tx_notch_freq %u\n", i, rfconf.freq_hz, rfconf.rssi_offset, rfconf.tx_enable, rfconf.tx_notch_freq);
        /* all parameters parsed, submitting configuration to the HAL */
        if (lgw_rxrf_setconf(i, rfconf) != LGW_HAL_SUCCESS)
        {
            MSG("ERROR: invalid configuration for radio %i\n", i);
            return -1;
        }

    }



    /* set configuration for LoRa multi-SF channels (bandwidth cannot be set) */
    for (i = 0; i < LGW_MULTI_NB; ++i) {
        memset(&ifconf, 0, sizeof(ifconf)); /* initialize configuration structure */
        ifconf.enable = IF_Conf[i].enable;
        ifconf.rf_chain=IF_Conf[i].rf_chain;
        ifconf.freq_hz= IF_Conf[i].if_fre;        
        /* all parameters parsed, submitting configuration to the HAL */
        if (lgw_rxif_setconf(i, ifconf) != LGW_HAL_SUCCESS) {
            MSG("ERROR: invalid configuration for Lora multi-SF channel %i\n", i);
            return -1;
        }
    }

    /* set configuration for LoRa standard channel */
    memset(&ifconf, 0, sizeof(ifconf)); /* initialize configuration structure */
    ifconf.enable = true;
    ifconf.rf_chain = 1;
    ifconf.freq_hz = -200000;
    ifconf.bandwidth = BW_250KHZ;  //[BW_125KHZ,BW_250KHZ,BW_500KHZ]
    ifconf.datarate = DR_LORA_SF7; //[DR_LORA_SF7..DR_LORA_SF12]
    printf("INFO: LoRa standard channel enabled, radio %i selected, IF %i Hz, 250KHz bandwidth, SF SF7\n", ifconf.rf_chain, ifconf.freq_hz);
    if (lgw_rxif_setconf(8, ifconf) != LGW_HAL_SUCCESS)
    {
        MSG("ERROR: invalid configuration for Lora standard channel\n");
        return -1;
    }

    /* set configuration for FSK channel */
    memset(&ifconf, 0, sizeof(ifconf)); /* initialize configuration structure */
    ifconf.enable = true;
    ifconf.rf_chain = 1;
    ifconf.freq_hz = 300000;
    ifconf.bandwidth = BW_125KHZ; //[BW_7K8HZ,BW_15K6HZ,BW_31K2HZ,BW_62K5HZ,BW_125KHZ,BW_250KHZ,BW_500KHZ]
    ifconf.datarate = 50000;
    printf("INFO: FSK channel enabled, radio %i selected, IF %i Hz, BW_125KHZ bandwidth, %u bps datarate\n", ifconf.rf_chain, ifconf.freq_hz, ifconf.datarate);

    if (lgw_rxif_setconf(9, ifconf) != LGW_HAL_SUCCESS)
    {
        MSG("ERROR: invalid configuration for FSK channel\n");
        return -1;
    }
    return 0;
}

int parse_gateway_configuration(const char * conf_file) {
    
    const char *str; /* pointer to sub-strings in the JSON data */
    unsigned long long ull = 0;
    /* getting network parameters (only those necessary for the packet logger) */
    str = "AA555A0000000000";
    if (str != NULL) {
        sscanf(str, "%llx", &ull);
        lgwm = ull;
        MSG("INFO: gateway MAC address is configured to %016llX\n", ull);
    }

    
    return 0;
}


/* describe command line options */
void usage(void) {
    printf("*** Library version information ***\n%s\n\n", lgw_version_info());
    printf( "Available options:\n");
    printf( " -h print this help\n");
    printf( " -r <int> rotate log file every N seconds (-1 disable log rotation)\n");
}

/* -------------------------------------------------------------------------- */
/* --- MAIN FUNCTION -------------------------------------------------------- */

int rx_test(void)
{
    int i, j; /* loop and temporary variables */
    // struct timespec sleep_time = {0, 3000000}; /* 3 ms */

    /* clock and log rotation management */
    int log_rotate_interval = 3600; /* by default, rotation every hour */
    int time_check = 0; /* variable used to limit the number of calls to time() function */
    unsigned long pkt_in_log = 0; /* count the number of packet written in each log file */

    

    /* allocate memory for packet fetching and processing */
    struct lgw_pkt_rx_s rxpkt[16]; /* array containing up to 16 inbound packets metadata */
    struct lgw_pkt_rx_s *p; /* pointer on a RX packet */
    int nb_pkt;

    /* local timestamp variables until we get accurate GPS time */
    // struct timespec fetch_time;
    // char fetch_timestamp[30];
    // struct tm * x;

    //config the RF Chain and IF chain
    parse_SX1301_configuration(0);
    parse_gateway_configuration(0);

    /* starting the concentrator */
    i = lgw_start();
    if (i == LGW_HAL_SUCCESS) {
        MSG("INFO: concentrator started, packet can now be received\n");
    } else {
        MSG("ERROR: failed to start the concentrator\n");
        return EXIT_FAILURE;
    }

    /* transform the MAC address into a string */
    sprintf(lgwm_str, "%08X%08X", (uint32_t)(lgwm >> 32), (uint32_t)(lgwm & 0xFFFFFFFF));

    // /* opening log file and writing CSV header*/
    // time(&now_time);
    

    /* main loop */
    while (1) {
        /* fetch packets */
        nb_pkt = lgw_receive(ARRAY_SIZE(rxpkt), rxpkt);
        if (nb_pkt == LGW_HAL_ERROR) {
            printf("ERROR: failed packet fetch, exiting\n");
            return EXIT_FAILURE;
        } else if (nb_pkt == 0) {
           wait_ms(10);
        } else {
            /* local timestamp generation until we get accurate GPS time */
            // clock_gettime(CLOCK_REALTIME, &fetch_time);
            // x = gmtime(&(fetch_time.tv_sec));
            // sprintf(fetch_timestamp,"%04i-%02i-%02i %02i:%02i:%02i.%03liZ",(x->tm_year)+1900,(x->tm_mon)+1,x->tm_mday,x->tm_hour,x->tm_min,x->tm_sec,(fetch_time.tv_nsec)/1000000); /* ISO 8601 format */
            printf("receive packet successfully\n");
        }

        /* log packets */
        for (i=0; i < nb_pkt; ++i) {
            p = &rxpkt[i];

            /* writing gateway ID */
            printf("the gateway mac is \"%08X%08X\",", (uint32_t)(lgwm >> 32), (uint32_t)(lgwm & 0xFFFFFFFF));

            

            

            /* writing internal clock */
            printf( "the internal clock is %10u,", p->count_us);

            /* writing RX frequency */
            printf("the RX frequency is %10u,", p->freq_hz);

            /* writing RF chain */
            printf("the RF chain is %u,", p->rf_chain);

            /* writing RX modem/IF chain */
            printf("the RX modem/IF chain is %2d,", p->if_chain);

            /* writing status */
            switch(p->status) {
                case STAT_CRC_OK:       printf("\"CRC_OK\" ,"); break;
                case STAT_CRC_BAD:      printf("\"CRC_BAD\"," ); break;
                case STAT_NO_CRC:       printf("\"NO_CRC\" ,"); break;
                case STAT_UNDEFINED:    printf("\"UNDEF\"  ,"); break;
                default:                printf("\"ERR\"    ,");
            }

            /* writing payload size */
            printf( "the payload size is %3u,", p->size);

            /* writing modulation */
            switch(p->modulation) {
                case MOD_LORA:  printf("the mode is \"LORA\","); break;
                case MOD_FSK:   printf("the mode is \"FSK\" ,"); break;
                default:        printf("\"ERR\" ,");
            }

            /* writing bandwidth */
            switch(p->bandwidth) {
                case BW_500KHZ:     printf("500000,"); break;
                case BW_250KHZ:     printf("250000,"); break;
                case BW_125KHZ:     printf("125000,"); break;
                case BW_62K5HZ:     printf("62500 ,"); break;
                case BW_31K2HZ:     printf("31200 ,"); break;
                case BW_15K6HZ:     printf("15600 ,"); break;
                case BW_7K8HZ:      printf("7800  ,"); break;
                case BW_UNDEFINED:  printf("0     ,"); break;
                default:            printf("-1    ,");
            }

            /* writing datarate */
            if (p->modulation == MOD_LORA) {
                switch (p->datarate) {
                    case DR_LORA_SF7:   printf("\"SF7\"   ,"); break;
                    case DR_LORA_SF8:   printf("\"SF8\"   ,"); break;
                    case DR_LORA_SF9:   printf("\"SF9\"   ,"); break;
                    case DR_LORA_SF10:  printf("\"SF10\"  ,"); break;
                    case DR_LORA_SF11:  printf("\"SF11\"  ,"); break;
                    case DR_LORA_SF12:  printf("\"SF12\"  ,"); break;
                    default:            printf("\"ERR\"   ,");
                }
            } else if (p->modulation == MOD_FSK) {
                printf("the FSK data rate is \"%6u\",", p->datarate);
            } else {
                printf("\"ERR\"   ,");
            }

            /* writing coderate */
            switch (p->coderate) {
                case CR_LORA_4_5:   printf("\"4/5\","); break;
                case CR_LORA_4_6:   printf("\"2/3\","); break;
                case CR_LORA_4_7:   printf("\"4/7\","); break;
                case CR_LORA_4_8:   printf("\"1/2\","); break;
                case CR_UNDEFINED:  printf("\"\"   ,"); break;
                default:            printf("\"ERR\",");
            }

            /* writing packet RSSI */
            printf("the RSSI is %+.0f,", p->rssi);

            /* writing packet average SNR */
            printf("the packet average SNR %+5.1f,\n", p->snr);

            /* writing hex-encoded payload (bundled in 32-bit words) */
            printf("the payload is \"");
            for (j = 0; j < p->size; ++j) {
                
                // printf("%02X ", p->payload[j]);
                printf("%c", p->payload[j]);
            }

            /* end of log file line */
            printf("\"\n");
            
            ++pkt_in_log;
        }

        /* check time and rotate log file if necessary */
        ++time_check;
        if (time_check >= 8) {
            time_check = 0;
            // printf("INFO:  %lu packet(s) recorded\n", pkt_in_log);
            pkt_in_log = 0;

        }
    }

    if (1) {
        /* clean up before leaving */
        i = lgw_stop();
        if (i == LGW_HAL_SUCCESS) {
            MSG("INFO: concentrator stopped successfully\n");
        } else {
            MSG("WARNING: failed to stop concentrator successfully\n");
        }
        
    }

    MSG("INFO: Exiting packet logger program\n");
    return EXIT_SUCCESS;
}

/* --- EOF ------------------------------------------------------------------ */

