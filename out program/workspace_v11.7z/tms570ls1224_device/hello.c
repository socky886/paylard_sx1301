#include <stdio.h>

#include "sci.h"
#include "gio.h"
#include "spi.h"
#include "het.h"
#include "sci.h"

#include <string.h>

#include "sx1301_app.h"

// weijunfeng added 2022-06-13
// alter this function to delay_ms
// the result is ok by test
void Delay(volatile int time)
{
	int temp = time;
	while(time--){
		volatile int mil_time = 10000;
		while(mil_time--);
	}
}


int32_t fputc(int32_t ch,FILE*f)
{
	uint8 xx=(uint8)ch;
    
	sciSendByte(sciREG,ch);
    return ch;
}

int fputs(const char *_ptr, register FILE *_fp)
{
  unsigned int i, len;

  len = strlen(_ptr);
  sciSend(sciREG,len,(uint8_t *)_ptr);

  return len;
}


/**
 * hello.c
 */
int main(void)
{
    sciInit();
    gioInit();
    spiInit();
    hetInit();

	spiDAT1_t dataconfig1_t;
    dataconfig1_t.CS_HOLD = FALSE;
    dataconfig1_t.WDEL = TRUE;
    dataconfig1_t.DFSEL = SPI_FMT_0;                 /* PHASE is 1, POLARITY is 0, charlen is 8bit */
    dataconfig1_t.CSNR = (~SPI_PIN_CS0) & 0xFF; /* Chip select */

	uint16 txData[8]={0x1101,0x1102,0x1103,0x1104,0x1105,0x1106,0x1107,0x1108};
	uint16 rxData[8];
	int i;

    // gioSetBit(spiPORT4, SPI_PIN_CS0, 0);

    // spiTransmitAndReceiveData(spiREG4, &dataconfig1_t, 1, &txData, &rxData);

    // gioSetBit(spiPORT4, SPI_PIN_CS0, 1);

	while (1)
	{
		sx1302_reset();
		// test_loragw_spi();
		// test_loragw_reg();
		//test_loragw_cw();
		// tx_test();
		rx_test();
		printf("this is sx1301 application\n");
		Delay(5000);
		// for ( i = 0; i < 8; i++)
		// {
		// 	txData[i]=0x5521+i;
		// }
		
		// gioSetBit(spiPORT4, SPI_PIN_CS0, 0);
		// spiTransmitAndReceiveData(spiREG4, &dataconfig1_t, 8, txData, rxData);
		// gioSetBit(spiPORT4, SPI_PIN_CS0, 1);
		// Delay(100);

		// for ( i = 0; i < 8; i++)
		// {
		// 	txData[i]=0x5511+i;
		// }
		
		// gioSetBit(spiPORT4, SPI_PIN_CS0, 0);
		// spiTransmitAndReceiveData(spiREG4, &dataconfig1_t, 8, txData, rxData);
		// gioSetBit(spiPORT4, SPI_PIN_CS0, 1);
		// Delay(100);

		

	}
	
	// printf("Hello World!\n");
	
	return 0;
}
